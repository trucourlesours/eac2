<?php
var_dump($_POST);
	$mon_image='soleil';
	$ma_taille=600;

	if(isset($_POST['image'])){
		$mon_image = $_POST['image'];
	}

	if(!empty($_POST['taille'])){
		$ma_taille = $_POST['taille'];
	}

	$qte=1;
	if(isset($_POST['qty'])){
		$qte = $_POST['qty'];
		$ma_taille= 600/$qte;
	}
?>


<html>
<head>
<style>
table,td{
	
	border:2px solid black;
	
}
img{
	<?php  
		if(isset($_POST['bordures'])){
			foreach ($_POST['bordures'] as $value) {
				print("border-".$value.":10px solid ".$_POST['bordcol'].";");
			}
		}
		else{
			print("border:10px solid ".$_POST['bordcol'].";");
		}
	?>
}
</style>
</head>

<body>
<div style='width:680px;margin:auto auto;' >
<?php
	for($i=0;$i<$qte;$i++){
		print("<img src='images/".$mon_image.".jpg' style='width:".$ma_taille."px' />");
	}
?>
</div>


<div style='width:400px;margin:30px auto'>
<form action="" method="post">
<table>

<tr><td>Choisir son image</td><td>
<select name="image">
<option value="soleil">Soleil</option>
<option value="mars">Mars</option>
<option value="jupiter">Jupiter</option>
</select>
</td></tr>

<tr><td>Entrez la taille de l'image</td><td><input type="number" name="taille" min="0"></td></tr>
<tr><td>Entrez les couleurs des bordures</td><td>
<input type="color" name="bordcol" value="#00ffff" /></td></tr>

<tr><td>Nombre d'images souhaitées</td><td>
<input type="radio" name="qty" value="1" />Une<br/>
<input type="radio" name="qty" value="2" />Deux<br/>
<input type="radio" name="qty" value="4" />Quatre<br/>
</td></tr>

<tr><td>Choisir ses bordures</td><td>
<input type="checkbox" value="top" name="bordures[]">Haut<br/>
<input type="checkbox" value="bottom" name="bordures[]">Bas<br/>
<input type="checkbox" value="right" name="bordures[]">Droite<br/>
<input type="checkbox" value="left" name="bordures[]">Gauche<br/>

</td></tr>



<tr><td></td><td><input type="submit" value="Valider" /></td></tr>
</table>
</form>
</div>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
</body>

</html>